This is an arXiv-ready LaTeX package for the K-Splanifold paper.

Compile:
    pdflatex main.tex
    pdflatex main.tex

Figures are in ./figures/.
